import { Component, EventEmitter } from 'angular2/core'

@Component({
    selector: 'my-vote',
    template: `
        <div class="voter">
            <i class="glyphicon glyphicon-menu-up vote-button" (click) = "upVote()" 
                [class.higlighted] = "myVote == 1" >
            </i>
            <span class="vote-count">{{ voteCount + myVote }}</span>
            <i class="glyphicon glyphicon-menu-down vote-button" (click) = "downVote()"
                [class.higlighted] = "myVote == -1" >
            </i>
        </div>    
    `,
    inputs: ['voteCount','myVote'],
    outputs: ['vote'],
    styles: [`
        .voter{
            width: 20px;
            text-align:center;
            color: #999;
        }
        .vote-button{
            cursor: pointer;
        }
        .higlighted{
            color: orange;
            font-weight: bold;
        }
        .vote-count{
            font-size: 1.2em;
        }
        `]
        
})

export class VoteComponent {
    voteCount: number = 0;
    myVote: number = 0;
    vote = new EventEmitter();
    
    upVote() {
        if(this.myVote == 1)
            return;
        this.myVote++;
        this.vote.emit({newValue: this.myVote});
    }
    
    downVote() {
        if(this.myVote == -1)
            return;
        this.myVote--;
        this.vote.emit({newValue: this.myVote});
    }
} 