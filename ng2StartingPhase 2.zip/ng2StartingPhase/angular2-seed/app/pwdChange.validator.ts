import { Control } from 'angular2/common';

export class PwdChangeValidator {
    static passwordLengthCheck(control: Control) {
        if(control.value.length <= 5){
            return {pwdLengthAbnormal: true,actualLength: 5}
        }
        else return null;
    }
    
    // static oldPwdCheck(control: Control) {
    //     return new Promise((resolve,reject)=>{
    //         setTimeout( ()=>{
    //             if(control.value !='1234'){
    //                 resolve({oldPwdEquality: true})
    //             }
    //             else resolve(null);
    //         })
    //     })
    // }
    
    // static pwdEqualityCheck(control: Control) {
    //     if(control.find('newPwd').value != control.find('confirmPwd').value){
    //         control.setErrors({passwordDontMatch: true})
    //     }
    // }
}