export class AuthorsService {
    get authors(): string[] {
        return ['Author1','Author2','Author3'];
    }
}