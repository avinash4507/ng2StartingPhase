System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var PwdChangeValidator;
    return {
        setters:[],
        execute: function() {
            class PwdChangeValidator {
                static passwordLengthCheck(control) {
                    if (control.value.length <= 5) {
                        return { pwdLengthAbnormal: true, actualLength: 5 };
                    }
                    else
                        return null;
                }
            }
            exports_1("PwdChangeValidator", PwdChangeValidator);
        }
    }
});
//# sourceMappingURL=pwdChange.validator.js.map