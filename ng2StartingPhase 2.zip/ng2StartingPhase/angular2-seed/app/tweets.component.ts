import { Component, EventEmitter } from 'angular2/core';
import { HeartComponent } from './heart.component';

@Component({
    selector: 'my-tweet',
    template: `
        <div class="media">
            <div class="media-left">
                <a href="#">
                <img class="media-object img-rounded " src="app/photo.jpg" alt="media Object here">
                </a>
            </div>
            <div class="media-body">
                <h4 class="media-heading">{{tweetAuthor}} <span class="lightColor">@{{tweeterHandle}}</span></h4>
                <my-heart [totalLikes]="myTweets" 
                    (click) = "onHeartClick()">
                </my-heart>
            </div>
        </div>
        <br/>
    `,
    directives:[ HeartComponent ],
    styles:[`
        .lightColor{
            color: #999;
        }
        .img-rounded{
            width:100px;
            height:100px;
        }
    `],
    inputs:['tweetAuthor','tweeterHandle','myTweets'],
    outputs:['tweets']
})

export class TweetsComponent {
    myTweets: number = 0;
    tweetAuthor: string = 'default';
    tweeterHandle: string = '@default';
    
    tweets = new EventEmitter();
    onHeartClick() {
        this.tweets.emit({newValue: this.myTweets});
    }
}