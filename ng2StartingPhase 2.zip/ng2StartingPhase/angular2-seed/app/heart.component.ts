import { Component, EventEmitter } from 'angular2/core'

@Component({
    selector: 'my-heart',
    templateUrl: 'app/heart.template.html',
    styles: [`
        .glyphicon-heart{
            color:#ccc;
            cursor: pointer;
        }
        .pink{
            color: deeppink;
            cursor: pointer;
        }
        
    `],
    inputs: ['likes: totalLikes','like: iLike'],
    outputs:['changeHeart: changeHeart']
})

export class HeartComponent {
    like: boolean;
    
    changeHeart = new EventEmitter();
    
    likes: number;
    onClick() {
        this.like = !this.like;
        this.likes += this.like ? 1 : -1;
        // if(this.like)
        //     this.likes++;
        // else
        //     this.likes--;
            
        this.changeHeart.emit({newVal: this.like});
    }
} 