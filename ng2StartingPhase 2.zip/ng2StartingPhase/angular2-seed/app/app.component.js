System.register(['angular2/router', 'angular2/core', './courses.component', './authors.component', './favorite.component', './heart.component', './vote.component', './tweets.component', './tweets.service', './pipe.component', './bootstrapPanel.component', './zippy.component', './contact-form.component', './exercise-form.component', './signup-form.component', './pwdChange.component', './observable.component', './post.service', 'angular2/http', './gthubUserProfile.component', './albums.component', './album.component', './contact.component', './archives.component', './archive.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var router_1, core_1, courses_component_1, authors_component_1, favorite_component_1, heart_component_1, vote_component_1, tweets_component_1, tweets_service_1, pipe_component_1, bootstrapPanel_component_1, zippy_component_1, contact_form_component_1, exercise_form_component_1, signup_form_component_1, pwdChange_component_1, observable_component_1, post_service_1, http_1, gthubUserProfile_component_1, albums_component_1, album_component_1, contact_component_1, archives_component_1, archive_component_1;
    var AppComponent;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (courses_component_1_1) {
                courses_component_1 = courses_component_1_1;
            },
            function (authors_component_1_1) {
                authors_component_1 = authors_component_1_1;
            },
            function (favorite_component_1_1) {
                favorite_component_1 = favorite_component_1_1;
            },
            function (heart_component_1_1) {
                heart_component_1 = heart_component_1_1;
            },
            function (vote_component_1_1) {
                vote_component_1 = vote_component_1_1;
            },
            function (tweets_component_1_1) {
                tweets_component_1 = tweets_component_1_1;
            },
            function (tweets_service_1_1) {
                tweets_service_1 = tweets_service_1_1;
            },
            function (pipe_component_1_1) {
                pipe_component_1 = pipe_component_1_1;
            },
            function (bootstrapPanel_component_1_1) {
                bootstrapPanel_component_1 = bootstrapPanel_component_1_1;
            },
            function (zippy_component_1_1) {
                zippy_component_1 = zippy_component_1_1;
            },
            function (contact_form_component_1_1) {
                contact_form_component_1 = contact_form_component_1_1;
            },
            function (exercise_form_component_1_1) {
                exercise_form_component_1 = exercise_form_component_1_1;
            },
            function (signup_form_component_1_1) {
                signup_form_component_1 = signup_form_component_1_1;
            },
            function (pwdChange_component_1_1) {
                pwdChange_component_1 = pwdChange_component_1_1;
            },
            function (observable_component_1_1) {
                observable_component_1 = observable_component_1_1;
            },
            function (post_service_1_1) {
                post_service_1 = post_service_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (gthubUserProfile_component_1_1) {
                gthubUserProfile_component_1 = gthubUserProfile_component_1_1;
            },
            function (albums_component_1_1) {
                albums_component_1 = albums_component_1_1;
            },
            function (album_component_1_1) {
                album_component_1 = album_component_1_1;
            },
            function (contact_component_1_1) {
                contact_component_1 = contact_component_1_1;
            },
            function (archives_component_1_1) {
                archives_component_1 = archives_component_1_1;
            },
            function (archive_component_1_1) {
                archive_component_1 = archive_component_1_1;
            }],
        execute: function() {
            let AppComponent = class AppComponent {
                constructor(tweetsService, _postService) {
                    this._postService = _postService;
                    this.viewMode = '';
                    this.toShow = true;
                    this.isActive = false;
                    this.title = 'Hii Angular2';
                    this.post = {
                        isFavorite: true
                    };
                    this.letsVote = {
                        voteCount: 10,
                        myVote: 0
                    };
                    this.tweet = {
                        noOfLikes: 12,
                        iLike: true
                    };
                    this.myTweets = tweetsService.Tweets;
                    // this._postService.createPost({userId: 1,title: 's',body: 's'});
                }
                ngOnInit() {
                    this._postService.getPosts()
                        .subscribe(post => {
                        // this.isLoading = false;
                        // console.log(post);
                    });
                }
                isVoteGiven($event) {
                    console.log('Vote given fxn called: ', $event);
                }
                onHeartChange($event) {
                    console.log('heartChange fxn called: ', $event);
                }
                onFavChange($event) {
                    console.log($event);
                }
                onDivClick() {
                    console.log('Div click activated');
                }
                onClick($event) {
                    $event.stopPropagation();
                    this.isActive = true;
                    console.log($event);
                }
            };
            AppComponent = __decorate([
                core_1.Component({
                    selector: 'my-app',
                    templateUrl: 'app/app.template.html',
                    directives: [courses_component_1.CoursesComponent, authors_component_1.AuthorsComponent, favorite_component_1.FavoriteIconComponent,
                        heart_component_1.HeartComponent, vote_component_1.VoteComponent, tweets_component_1.TweetsComponent, pipe_component_1.PipeComponent,
                        bootstrapPanel_component_1.BootstrapPanelComponent, zippy_component_1.ZippyComponent, contact_form_component_1.ContactFormComponent,
                        exercise_form_component_1.ExerciseFormComponent, signup_form_component_1.SignupComponent, pwdChange_component_1.PwdChangeComponent,
                        observable_component_1.ObservableComponent, gthubUserProfile_component_1.GithubUserProfileComponent, router_1.RouterOutlet, router_1.RouterLink],
                    providers: [tweets_service_1.TweetsService, post_service_1.PostService, http_1.HTTP_PROVIDERS]
                }),
                router_1.RouteConfig([
                    {
                        path: "/albums",
                        name: "Albums",
                        component: albums_component_1.AlbumsComponent,
                        useAsDefault: true
                    },
                    {
                        path: "/contact",
                        name: "Contact",
                        component: contact_component_1.ContactComponent
                    },
                    {
                        path: "/albums/:id",
                        name: "Album",
                        component: album_component_1.AlbumComponent
                    },
                    {
                        path: "/archives",
                        name: "Archives",
                        component: archives_component_1.ArchivesComponent
                    },
                    {
                        path: "/archives/:year/:month",
                        name: "Archive",
                        component: archive_component_1.ArchiveComponent
                    },
                    {
                        path: "/*other",
                        name: "Other",
                        redirectTo: ['Albums']
                    }
                ]), 
                __metadata('design:paramtypes', [tweets_service_1.TweetsService, post_service_1.PostService])
            ], AppComponent);
            exports_1("AppComponent", AppComponent);
        }
    }
});
//# sourceMappingURL=app.component.js.map