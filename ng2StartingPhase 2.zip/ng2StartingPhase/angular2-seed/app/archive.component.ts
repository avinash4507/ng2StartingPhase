import { Component, OnInit } from 'angular2/core';
import { RouteParams } from 'angular2/router';

@Component({
    template: `
        <h2>Archive</h2>
        {{year}}/{{month}}
    `
})

export class ArchiveComponent implements OnInit {
    year: number;
    month: number;
    constructor(private _routeParams: RouteParams) {
        
    }
    
    ngOnInit() {
        this.year = parseInt(this._routeParams.get('year'));
        this.month = parseInt(this._routeParams.get('month'));
    }
    
}