export class TweetsService {
    get Tweets() {
        return [
            {tweetAuthor: 'Avinash', tweeterHandle: 'Singh', noOfLikes: 1},
            {tweetAuthor: 'ravi', tweeterHandle: 'pandey', noOfLikes: 2},
            {tweetAuthor: 'kiran', tweeterHandle: 'saroha', noOfLikes: 3},
        ];
    }
}