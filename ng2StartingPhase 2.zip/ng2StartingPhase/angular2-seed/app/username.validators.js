System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var UsernameValidators;
    return {
        setters:[],
        execute: function() {
            class UsernameValidators {
                static cannotContainSpace(control) {
                    if (control.value.indexOf(' ') >= 0) {
                        return { containsSpace: true };
                    }
                    else
                        return null;
                }
                static shouldBeUnique(control) {
                    return new Promise((resolve, reject) => {
                        setTimeout(() => {
                            if (control.value == "avinash")
                                resolve({ shouldBeUnique: true });
                            else
                                resolve(null);
                        }, 2000);
                    });
                }
            }
            exports_1("UsernameValidators", UsernameValidators);
        }
    }
});
//# sourceMappingURL=username.validators.js.map