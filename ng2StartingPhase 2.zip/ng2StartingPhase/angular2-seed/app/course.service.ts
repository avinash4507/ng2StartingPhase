export class CourseService {
    get Courses(): string[] {
        return ['course1','course2','course3'];
    }
}