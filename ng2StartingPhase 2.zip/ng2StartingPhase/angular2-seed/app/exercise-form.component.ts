import { Component } from 'angular2/core';

@Component({
    selector: 'exercise-form',
    templateUrl: 'app/exercise-form.template.html',
})

export class ExerciseFormComponent {
    log(emailObj) {
        console.log('emailObj: ',emailObj);
    }
    
    logMyForm(formObj) {
        console.log("formObj: ",formObj)
    }
}