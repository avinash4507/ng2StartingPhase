import { Component, Input, Output, EventEmitter } from 'angular2/core';

@Component({
    selector: 'bs-panel',
    template: `
        <div class = "panel panel-default" 
            [ngClass] = "{shortenWidth: showClass,
                          'Longen-Width': !showClass}">
            <div class = "panel-heading" (click) = "onBodyClick()">
                <ng-content select = ".heading"></ng-content>
                aaaaaa
            </div>
            <div class = "panel-body">
                <ng-content select = ".body"></ng-content>
            </div>
        </div>
    `,
    styles : [`
        .shortenWidth {
            width: 300px;
        },
        .Longen-Width {
            width: 600px;
        }`],
    inputs: ['showClass: showClass'],
    outputs:['fromBody: fromBody']
})

export class BootstrapPanelComponent {
    showClass: boolean = !true;
    addToBody: string = 'default';
    fromBody = new EventEmitter();
    
    onBodyClick() {
        this.fromBody.emit({newValue: this.showClass})
    }
} 