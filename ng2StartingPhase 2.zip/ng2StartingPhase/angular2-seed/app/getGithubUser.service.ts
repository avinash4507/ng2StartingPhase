import { Injectable } from 'angular2/core';
import { Http } from 'angular2/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

@Injectable()

export class GithubUserService {
    private _url: string = 'https://api.github.com/users/';
    
    constructor(private _http: Http) {
        
    }
    
    getUserProfile(userName) {
        return this._http.get(this._url + userName)
            .map(data => data.json());
    }
    
    getUserFollowers(username) {
        return this._http.get(this._url + username + '/followers')
            .map(data => data.json());
    }
}