System.register(['angular2/core', './heart.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, heart_component_1;
    var TweetsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (heart_component_1_1) {
                heart_component_1 = heart_component_1_1;
            }],
        execute: function() {
            let TweetsComponent = class TweetsComponent {
                constructor() {
                    this.myTweets = 0;
                    this.tweetAuthor = 'default';
                    this.tweeterHandle = '@default';
                    this.tweets = new core_1.EventEmitter();
                }
                onHeartClick() {
                    this.tweets.emit({ newValue: this.myTweets });
                }
            };
            TweetsComponent = __decorate([
                core_1.Component({
                    selector: 'my-tweet',
                    template: `
        <div class="media">
            <div class="media-left">
                <a href="#">
                <img class="media-object img-rounded " src="app/photo.jpg" alt="media Object here">
                </a>
            </div>
            <div class="media-body">
                <h4 class="media-heading">{{tweetAuthor}} <span class="lightColor">@{{tweeterHandle}}</span></h4>
                <my-heart [totalLikes]="myTweets" 
                    (click) = "onHeartClick()">
                </my-heart>
            </div>
        </div>
        <br/>
    `,
                    directives: [heart_component_1.HeartComponent],
                    styles: [`
        .lightColor{
            color: #999;
        }
        .img-rounded{
            width:100px;
            height:100px;
        }
    `],
                    inputs: ['tweetAuthor', 'tweeterHandle', 'myTweets'],
                    outputs: ['tweets']
                }), 
                __metadata('design:paramtypes', [])
            ], TweetsComponent);
            exports_1("TweetsComponent", TweetsComponent);
        }
    }
});
//# sourceMappingURL=tweets.component.js.map