import { Component } from 'angular2/core';
import { SummaryPipe } from './summary.pipe';

@Component({
    selector: 'my-pipe',
    template: `
        <div>
            {{myData | summary: 10}}
            {{task.assignee?.role?.name}}
        </div>
    `,
    pipes: [ SummaryPipe ]
})

export class PipeComponent {
    myData: string = `Hi this is avinash here.. i am trying to learn angular2 using typescript..
                      lets make it fun and use all i can ..lets get to the top of it`;

    task = {
        title: 'Review Applications',
        assignee: {
            role: {
                name: 'Avinash Singh'
            }
        }
    }
} 