import { RouteConfig, RouterOutlet, RouterLink } from 'angular2/router';
import { Component, OnInit } from 'angular2/core';
import { CoursesComponent } from './courses.component';
import { AuthorsComponent } from './authors.component';
import { FavoriteIconComponent } from './favorite.component';
import { HeartComponent } from './heart.component';
import { VoteComponent } from './vote.component';
import { TweetsComponent } from './tweets.component';
import { TweetsService } from './tweets.service';
import { PipeComponent } from './pipe.component';
import { BootstrapPanelComponent } from './bootstrapPanel.component';
import { ZippyComponent } from './zippy.component'
import { ContactFormComponent } from './contact-form.component'
import { ExerciseFormComponent } from './exercise-form.component';
import { SignupComponent } from './signup-form.component';
import { PwdChangeComponent } from './pwdChange.component';
import { ObservableComponent } from './observable.component';
import { Observable } from 'rxjs/Rx';
import { PostService } from './post.service';
import { HTTP_PROVIDERS } from 'angular2/http';
import { PostInterface } from './post.interface';
import { GithubUserProfileComponent } from './gthubUserProfile.component';
import { AlbumsComponent } from './albums.component';
import { AlbumComponent } from './album.component';
import { ContactComponent } from './contact.component';
import { ArchivesComponent } from './archives.component';
import { ArchiveComponent } from './archive.component';


@Component({
    selector: 'my-app',
    templateUrl: 'app/app.template.html',
    directives: [ CoursesComponent, AuthorsComponent, FavoriteIconComponent,
                 HeartComponent, VoteComponent, TweetsComponent, PipeComponent,
                 BootstrapPanelComponent, ZippyComponent, ContactFormComponent,
                 ExerciseFormComponent, SignupComponent, PwdChangeComponent,
                 ObservableComponent, GithubUserProfileComponent, RouterOutlet, RouterLink ],
    providers: [ TweetsService, PostService, HTTP_PROVIDERS  ]
})
@RouteConfig([
    { 
        path: "/albums", 
        name: "Albums", 
        component: AlbumsComponent, 
        useAsDefault: true 
    },
    { 
        path: "/contact", 
        name: "Contact", 
        component: ContactComponent 
    },
    {
        path: "/albums/:id",
        name: "Album",
        component: AlbumComponent  
    },
    {
        path: "/archives",
        name: "Archives",
        component: ArchivesComponent  
    },
    {
        path: "/archives/:year/:month",
        name: "Archive",
        component: ArchiveComponent  
    },
    { 
        path: "/*other", 
        name: "Other", 
        redirectTo: ['Albums'] 
    }
])
export class AppComponent implements OnInit{
    viewMode: string = '';
    toShow: boolean = true;
    // isLoading = true;
    
    myTweets;
    constructor(tweetsService: TweetsService, private _postService: PostService){
        this.myTweets = tweetsService.Tweets;
        // this._postService.createPost({userId: 1,title: 's',body: 's'});
        
    }
    ngOnInit() {
        this._postService.getPosts()
            .subscribe(post => {
                // this.isLoading = false;
                // console.log(post);
            });
    }
    
    
    isActive = false;
    title: string = 'Hii Angular2';
    post={
        isFavorite:true
    }
    letsVote = {
        voteCount: 10,
        myVote: 0
    }
    isVoteGiven($event){
        console.log('Vote given fxn called: ',$event);
    }
    tweet = {
        noOfLikes: 12,
        iLike: true
    }
    onHeartChange($event) {
        
        console.log('heartChange fxn called: ',$event)
    }
    onFavChange($event) {
        console.log($event);
    }
    onDivClick() {
        console.log('Div click activated');
    }
    onClick($event) {
        $event.stopPropagation();
        this.isActive = true;
        console.log($event);
    }
 }