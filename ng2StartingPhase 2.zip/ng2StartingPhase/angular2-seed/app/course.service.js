System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var CourseService;
    return {
        setters:[],
        execute: function() {
            class CourseService {
                get Courses() {
                    return ['course1', 'course2', 'course3'];
                }
            }
            exports_1("CourseService", CourseService);
        }
    }
});
//# sourceMappingURL=course.service.js.map