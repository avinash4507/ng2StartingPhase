import { Component, OnInit } from 'angular2/core';
import { GithubUserService } from './getGithubUser.service';
import { HTTP_PROVIDERS } from 'angular2/http';
import { Observable } from 'rxjs/Rx';

@Component({
    selector: 'github-user',
    template: `
        <i *ngIf="isLoading" class="fa fa-spinner fa-pulse fa-5x"></i>
        <h3>@{{loginUserName.login}}</h3>
        <p>
            <img class="media-object img-circle img-height-width"
                src="{{loginUserName.avatar_url}}" alt="media Object here">
        </p> 
        <h4>Followers</h4>
        <div class="media" *ngFor= "#follower of followers">
            <div class="media-left">
                <a href="#">
                <img class="media-object img-circle img-height-width" src="{{follower.avatar_url}}"
                     alt="followers">
                </a>
            </div>
            <div class="media-body">
                <h5 class="media-heading">{{follower.login}}</h5>
            </div>
        </div>
        
    `,
    styles: [`
       .img-height-width {
           height:100px;
           width:100px;
       } 
    `],
    providers: [ GithubUserService, HTTP_PROVIDERS ]
})

export class GithubUserProfileComponent implements OnInit{
    loginUserName = {};
    followers = [];
    userName: string = 'octocat';
    isLoading: boolean = true;
    constructor(private _githubUserService: GithubUserService) {
        
    }
    
    ngOnInit() {
        Observable.forkJoin(
            this._githubUserService.getUserProfile(this.userName),
            this._githubUserService.getUserFollowers(this.userName)
        )
        .subscribe(data => {
            this.loginUserName = data[0];
            this.followers = data[1];
        },
        error => console.log('error', error),
        () => { this.isLoading = false; });
        
        // this._githubUserService.getUserProfile(this.userName)
        //     .subscribe(data => {
        //         this.loginUserName = data;
        //         console.log(data)
        //     });
        // this._githubUserService.getUserFollowers(this.userName)
        //     .subscribe(data => {
        //         this.followers = data; 
        //     });
    }
}