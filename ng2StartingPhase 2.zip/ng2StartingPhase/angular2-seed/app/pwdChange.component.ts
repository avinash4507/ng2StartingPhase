import { Component } from 'angular2/core';
import { ControlGroup, Control, FormBuilder, Validators } from 'angular2/common';
import { PwdChangeValidator } from './pwdChange.validator';
@Component({
    selector: 'pwd-change',
    templateUrl: 'app/pwdChange.template.html'
})

export class PwdChangeComponent {
    form: ControlGroup;
    constructor(fb: FormBuilder) {
        this.form = fb.group({
            oldPwd: ['',Validators.compose([Validators.required])],
            newPwd: ['',Validators.compose([Validators.required,PwdChangeValidator.passwordLengthCheck])],
            confirmPwd: ['',Validators.required]
        })
    }
    
    onPwdChange() {
        
        if(this.form.value.newPwd != this.form.value.confirmPwd) {
            this.form.find('confirmPwd').setErrors({
                passwordsDontMatch: true
            })
        }
        if(this.form.value.oldPwd!='1234'){
            this.form.find('oldPwd').setErrors({
                oldPwdNotEquality: true
            })
        }
        console.log(this.form)
    }
}
