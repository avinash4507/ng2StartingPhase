import { Component } from 'angular2/core';
import { Observable } from 'rxjs/Rx';

@Component({
    selector: 'my-observable',
    template: `
        <input id="search" type="text" class="form-control" placeholder="Search" />
        `
})

export class ObservableComponent {
    constructor() {
        var keyups = Observable.fromEvent($('#search'),"keydown");
        
        keyups.subscribe(data => console.log(data));
    }
}