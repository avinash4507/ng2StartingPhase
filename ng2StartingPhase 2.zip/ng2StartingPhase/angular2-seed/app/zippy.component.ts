import { Component, Input } from 'angular2/core';

@Component({
    selector: 'my-zippy',
    template: `
        <div class = "panel panel-default"> 
            <div class = "panel-heading">
                {{title}}
                <i class = "glyphicon pull-right" 
                    [ngClass] = "{
                        'glyphicon-chevron-down': !showBody,
                        'glyphicon-chevron-up': showBody
                    }" 
                    (click)="onIconClick()">
                </i>
            </div>
            <div class = "panel-body" *ngIf = "showBody">
                <ng-content select = ".body"></ng-content>
            </div>
        </div>
    `,
    inputs: ['title'],
    styles: [`
        .panel{
            margin-bottom:0px;
            padding-bottom:0px;
        },
        .glyphicon-chevron-down{
            cursor: pointer;
        }
    `]
})

export class ZippyComponent {
    title: string = 'title'
    showBody: boolean = true;
    onIconClick() {
        this.showBody = !this.showBody;
    }
}