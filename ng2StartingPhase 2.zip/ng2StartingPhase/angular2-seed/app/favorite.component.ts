import { Component, Input, Output, EventEmitter } from 'angular2/core'

@Component({
    selector: "my-favorite",
    template: `
        <i class = "glyphicon" 
            [class.glyphicon-star] = "isFavorite" 
            [class.glyphicon-star-empty]="!isFavorite"
            
            [ngClass] = "{
                'glyphicon-star': isFavorite,
                'glyphicon-star-empty': !isFavorite
            }" 
            (click)="onStarClick()">
        </i>
    `,
    styles:[`
        .glyphicon-star{
            color:red;
        },
        .glyphicon-star-empty{
            color:red;
            border: 2px;
        }
    `],
    inputs: ['isFavorite: is-fav'],
    outputs: ['changeEvent: change']
})

export class FavoriteIconComponent {
    // @Input('is-fav') isFavorite: boolean = false;
    isFavorite: boolean = false;
    
    // @Output('change') changeEvent = new EventEmitter();
    changeEvent = new EventEmitter();
    
    onStarClick() {
        this.isFavorite = !this.isFavorite;
        this.changeEvent.emit({ newValue: this.isFavorite });
    }
    
}