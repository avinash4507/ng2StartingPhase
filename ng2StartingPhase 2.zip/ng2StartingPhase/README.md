# ng2StartingPhase
angular 2 learning
